everything is contained within VariantsC.dll

#### Full Elite



Adds Full Elite **Jadebox**: 

*Draft 4 cards before the debut. Start with |Block Toys|. All normal encounters contain an elite enemy instead.*


---
*Change log*

`0.9.0` added Rainbow Full Elite jadebox. Reorganized starting bonuses.

`0.6.0` added more difficult Full Elite jadebox variation. Demoted original jadebox to EASY mode.
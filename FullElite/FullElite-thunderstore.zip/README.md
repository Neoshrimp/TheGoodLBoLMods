### Full Elite

*Korean translation by **raspberry Caffeine Monster***

![bigRin](https://github.com/Neoshrimp/TheGoodLBoLMods/assets/89428565/b0c00804-c679-47d8-a31f-93919b27719e)
*Find Big Rin in Rainbow box!*


Challenge mode where every regular encounter contains an elite.

Challenge is selectable and configurable via jadeboxes. Jadebox bonuses are pretty much mandatory for a clear but starting cards and power should be enough to clear L7.

[Rainbow box details](https://github.com/Neoshrimp/TheGoodLBoLMods/blob/master/FullElite/RainbowPoolingRules.md) (somewhat spoilers)

---
*Change log*

`1.1.2` Add Korean localization.

`1.1.0` Nerf act 1 Youmu and terminator drone Defense Matrix.

`1.0.0` **WORS ONLY WITH GAME VERSION 1.4+ (beta branch)** Changed Rainbow Elite pooling rules. Buffed some act 3 elites.

`0.9.1` Bug fix: big elites can only be encountered in act 3.

`0.9.0` added Rainbow Full Elite jadebox. Reorganized starting bonuses.

`0.6.0` added more difficult Full Elite jadebox variation. Demoted original jadebox to EASY mode.

### Full Elite

![bigRin](https://github.com/Neoshrimp/TheGoodLBoLMods/assets/89428565/b0c00804-c679-47d8-a31f-93919b27719e)
*Find Big Rin in Rainbow box!*


Challenge mode where every regular encounter contains an elite.

Challenge is selectable and configurable via jadeboxes. Jadebox bonuses are pretty much mandatory for a clear but starting cards and power should be enough to clear L7.

[Rainbow box details](https://pastebin.com/c7Nv6fCF) (somewhat spoilers)

---
*Change log*

`0.9.0` added Rainbow Full Elite jadebox. Reorganized starting bonuses.

`0.6.0` added more difficult Full Elite jadebox variation. Demoted original jadebox to EASY mode.

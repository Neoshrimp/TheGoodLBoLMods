### Full Elite

*Korean translation by **raspberry Caffeine Monster***
**Korean translation slightly outdated**

![bigRin](https://github.com/Neoshrimp/TheGoodLBoLMods/assets/89428565/b0c00804-c679-47d8-a31f-93919b27719e)


Challenge mode where every regular encounter contains an elite.

Challenge is selectable and configurable via jadeboxes. Some starting bonus are pretty much mandatory but can be disabled by toggling specific jadebox.

[Rainbow box details](https://github.com/Neoshrimp/TheGoodLBoLMods/blob/master/FullElite/RainbowPoolingRules.md) (somewhat spoilers)

---
*Change log*

`1.1.60` Nerf summoned Reimu orbs. Make starting bonuses implicit with full elite boxes. Compatible with **both** LBoL 1.5.x and 1.6.0.

`1.1.51` Fix extra reward exhibit bonus not working after restart.

`1.1.50` Update Ko translation.

`1.1.40` Add 'Reward Exhibit' bonus jadebox.

`1.1.30` Reduce Doremy's barrier and hp gain in earlier acts.

`1.1.2` Add Korean localization.

`1.1.0` Nerf act 1 Youmu and terminator drone Defense Matrix.

`1.0.0` **WORS ONLY WITH GAME VERSION 1.4+ (beta branch)** Changed Rainbow Elite pooling rules. Buffed some act 3 elites.

`0.9.1` Bug fix: big elites can only be encountered in act 3.

`0.9.0` added Rainbow Full Elite jadebox. Reorganized starting bonuses.

`0.6.0` added more difficult Full Elite jadebox variation. Demoted original jadebox to EASY mode.

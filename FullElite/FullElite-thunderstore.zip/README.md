#### Full Elite

Adds Full Elite **Jadebox**: 

*Draft 4 cards before the debut. Start with |Block Toys|. All normal encounters contain an elite enemy instead.*
